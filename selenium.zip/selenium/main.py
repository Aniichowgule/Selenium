import json
import time
import os
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By


def load_user_credentials():
    try:
        with open('credentials.json', 'r') as credentials_file:
            data = json.load(credentials_file)
        return data['username'],data['password']
    except Exception as error:
        print(f"Error occurred while loading credentials:{error}")
        return None, None


def login_to_sauce_demo_account(user_name, user_password):
    driver = webdriver.Chrome()  
    driver.get('https://www.saucedemo.com/')

   
    username_input = driver.find_element(By.ID,'user-name')
    password_input = driver.find_element(By.ID,'password')
    login_btn = driver.find_element(By.ID,'login-button')

    username_input.send_keys(user_name)
    password_input.send_keys(user_password)
    login_btn.click()

    time.sleep(2)

    
    if "inventory.html" in driver.current_url:
        print("Login was successful!")
    else:
        print("Login failed. Please check your credentials.")
    
    return driver



def fetch_product_details(driver):
    products = {}

    try:
        
        product_elements = driver.find_elements(By.CLASS_NAME,'inventory_item')

        
        for product in product_elements:
            title = product.find_element(By.CLASS_NAME,'inventory_item_name').text
            description = product.find_element(By.CLASS_NAME,'inventory_item_desc').text
            price = product.find_element(By.CLASS_NAME,'inventory_item_price').text

            
            products[title] = {'description': description,'price': price}

        with open('product_details.json', 'w') as product_file:
            json.dump(products, product_file, indent=4)
        print("Product details successfully saved in product_details.json")

    except Exception as error:
        print(f"Error while extracting product details:{error}")


def update_price_of_third_product():
    try:
        
        with open('product_details.json','r') as file:
            products = json.load(file)

        print(f"Loaded product data:{products}")

        if len(products)<3:
            print("Insufficient number of products available.")
            return

        product_titles = list(products.keys())
        third_product = product_titles[2]
        original_price = products[third_product]['price']
        print(f"Original price of '{third_product}':{original_price}")
        
        products[third_product]['price'] ="$100"
        print(f"Updated price of '{third_product}':$100")

        with open('product_details.json','w') as file:
            json.dump(products, file, indent=4)
        print("Updated product details saved successfully.")

    except Exception as error:
        print(f"Error during price update:{error}")


def fetch_and_save_api_title():
    try:
        response = requests.get("https://jsonplaceholder.typicode.com/todos/1")
        response.raise_for_status()  
        data = response.json()
    
        title = "Hello World"

        with open('api_title.json','w') as file:
            json.dump({"title": title}, file,indent=4)
        
        print("API title successfully saved in api_title.json")
        print(f"Saved title:{title}")  

    except requests.exceptions.RequestException as error:
        print(f"Error fetching title from API:{error}")



def main():
    username, password = load_user_credentials()
    if not username or not password:
        print("Invalid credentials. Please check your credentials.json file.")
        return

    driver = login_to_sauce_demo_account(username,password)

    fetch_product_details(driver)
    update_price_of_third_product()
    fetch_and_save_api_title()
    driver.quit()
    print("Browser closed successfully.")


if __name__ == "__main__":
    main()
